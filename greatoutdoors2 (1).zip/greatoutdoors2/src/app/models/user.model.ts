export class User{
    userId : String;
    userName : String;
    userMail : String;
    userPassword : String;
    userNumber : number;
    userCategory : number;
    userActiveStatus : boolean;
}