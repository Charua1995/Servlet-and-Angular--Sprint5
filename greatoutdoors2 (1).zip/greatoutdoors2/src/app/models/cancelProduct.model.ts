export class CancelProductModel {
    userId: String;
    orderId: String;
    productId: String;
    quantity: String;
}