export class CancelOrderModel {
    userId: String;
    orderId: String;
}