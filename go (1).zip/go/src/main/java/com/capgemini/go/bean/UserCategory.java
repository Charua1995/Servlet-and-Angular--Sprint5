package com.capgemini.go.bean;

public enum UserCategory {
	
	GO_ADMIN,
	SALES_REPRESENTATIVE,
	RETAILER,
	PRODUCT_MASTER

};
